# G N U P L O T : template made by HPx-2.4 /F/MF/003 released on 11 10 2017
#
# Diederik Jacques and Jirka Simunek
#
# PROJECT FOLDER: Y:\Software Development\MFTHP\Verification\HPx\1D\0220 - Reactive Transport\ADR-R-SS1-HP1 
#
set terminal wxt enhanced
set size ratio 0 1,1
set style data lines
set zero 1e-008
set border 31 front linetype -1 linewidth 1.000
set grid
set title "" 
set title  offset character 0, 0, 0 font "" norotate
set timestamp  "" 
set timestamp bottom
set timestamp  offset character 0, 0, 0 font "" norotate
set xrange  [ * : * ] noreverse nowriteback 
set yrange  [ * : * ] noreverse nowriteback 
set xlabel offset character 0, 1, 0 font "" textcolor lt -1 norotate
set ylabel offset character 0, 0, 0 font "" textcolor lt -1 rotate by 90
set xtics border out scale 3,1.5 nomirror norotate  offset character 0, 0.5, 0 autofreq
set ytics border out scale 2,1 nomirror norotate  offset character 0.5, 0, 0 autofreq
set mxtics 2
set mytics 2
set key title ""
set key outside right top Left reverse noautotitle nobox enhanced
set key noinvert samplen 2 spacing 1 width 0 height 0
_HP_Tag = "Profile"
_HP_VariableType = "General Variable"
_HP_Variable = "pH"
set xlabel "pH "
set ylabel "Distance (cm)"
plot 'nod_inf_chem.out' using 4:2 index 0:0 title "         0.0 days " linestyle 1 , \
     'nod_inf_chem.out' using 4:2 index 1:1 title "       250.0 days " linestyle 2 , \
     'nod_inf_chem.out' using 4:2 index 2:2 title "       500.0 days " linestyle 3 , \
     'nod_inf_chem.out' using 4:2 index 3:3 title "       750.0 days " linestyle 4 , \
     'nod_inf_chem.out' using 4:2 index 4:4 title "      1000.0 days " linestyle 5 
# EOF