from numpy import *
time, sol3 = loadtxt('solute3.out',skiprows=4,comments="e",unpack=True, usecols=[0,3])
sol4 = loadtxt('solute4.out',skiprows=4,comments="e",unpack=True, usecols=[3])
savetxt('gasflux.out',column_stack((time,sol3+sol4)), fmt=('%9.8e', '%9.8e'))


