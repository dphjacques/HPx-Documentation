# G N U P L O T : template made by HP1-2.4.001 (MV_2.4.001_B006) released on 22 09 2016
#
# Diederik Jacques and Jirka Simunek
#
# PROJECT FOLDER: D:\Model Projects\HP1\Verification cases\1D\0230 - Gas diffusion\GAS-SS-EF-HP1 
#
set terminal wxt enhanced
set size ratio 0 1,1
set style data lines
set zero 1e-008
set border 31 front linetype -1 linewidth 1.000
set grid
set title "" 
set title  offset character 0, 0, 0 font "" norotate
set timestamp  "" 
set timestamp bottom
set timestamp  offset character 0, 0, 0 font "" norotate
set xrange  [ * : * ] noreverse nowriteback 
set yrange  [ * : * ] noreverse nowriteback 
set xlabel offset character 0, 1, 0 font "" textcolor lt -1 norotate
set ylabel offset character 0, 0, 0 font "" textcolor lt -1 rotate by 90
set xtics border out scale 3,1.5 nomirror norotate  offset character 0, 0.5, 0 autofreq
set ytics border out scale 2,1 nomirror norotate  offset character 0.5, 0, 0 autofreq
set mxtics 2
set mytics 2
set key title ""
set key outside right top Left reverse noautotitle nobox enhanced
set key noinvert samplen 2 spacing 1 width 0 height 0
set xlabel "Time (days)"
set ylabel "Gc(g) (mol/dm^3)"
plot 'obs_nod_chem1.out' using 3:9 title "         0.0 m " linestyle 1 , \
     'obs_nod_chem6.out' using 3:9 title "        -0.1 m " linestyle 2 , \
     'obs_nod_chem11.out' using 3:9 title "        -0.1 m " linestyle 3 , \
     'obs_nod_chem21.out' using 3:9 title "        -0.2 m " linestyle 4 , \
     'obs_nod_chem41.out' using 3:9 title "        -0.4 m " linestyle 5 , \
     'obs_nod_chem76.out' using 3:9 title "        -0.8 m " linestyle 6 , \
     'obs_nod_chem101.out' using 3:9 title "        -1.0 m " linestyle 7 
# EOF